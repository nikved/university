# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
University::Application.config.secret_token = 'c286ec71c8b09687cb51937a0f5df35ead8f35b9f5355c6110b3e30b65089f1a823aa3baaa8372fe255e1bf481a043ab98e260c568958e5836c4eb6956798fa2'
