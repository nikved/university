class BranchesController < InheritedResources::Base
end
