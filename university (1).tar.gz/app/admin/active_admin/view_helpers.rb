module ActiveAdmin::ViewHelpers

  def day_names
    Day::DAYNAES
  end

end