require 'spec_helper'

describe ApplicationDecorator do
end
