require 'spec_helper'

describe ScheduleDecorator do
  before { ApplicationController.new.set_current_view_context }
end
