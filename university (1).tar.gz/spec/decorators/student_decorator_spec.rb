require 'spec_helper'

describe StudentDecorator do
  before { ApplicationController.new.set_current_view_context }
end
