require 'test_helper'

class GroupMailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
