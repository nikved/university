require 'test_helper'

class ExamsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
