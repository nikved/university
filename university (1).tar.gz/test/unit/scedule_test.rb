require 'test_helper'

class SceduleTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
