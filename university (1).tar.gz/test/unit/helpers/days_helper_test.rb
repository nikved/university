require 'test_helper'

class DaysHelperTest < ActionView::TestCase
end
