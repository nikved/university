require 'test_helper'

class CathedrasHelperTest < ActionView::TestCase
end
