require 'test_helper'

class StudentsHelperTest < ActionView::TestCase
end
