require 'test_helper'

class AdminRoleTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
