require 'test_helper'

class AbilityItemTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
