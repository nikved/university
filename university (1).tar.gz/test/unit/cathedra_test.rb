require 'test_helper'

class CathedraTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
