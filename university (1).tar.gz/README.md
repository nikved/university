    run server

    cd some_path/university
    bundle install # install gems
    rake db:create # create database
    rake db:migrate # run migrations
    rake db:seed # populate with data
    rails s # run server
